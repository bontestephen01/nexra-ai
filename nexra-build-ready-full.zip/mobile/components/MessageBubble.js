import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { Audio } from 'expo-av';

export default function MessageBubble({ item }) {
  const isUser = item.role === 'user';

  if (item.type === 'image') {
    return (
      <View style={[styles.bubble, isUser ? styles.userBubble : styles.assistantBubble]}>
        <Image source={{ uri: item.content }} style={{ width: 220, height: 140, borderRadius:8 }} />
        {item.caption ? <Text style={styles.caption}>{item.caption}</Text> : null}
      </View>
    );
  }

  if (item.type === 'audio') {
    return (
      <View style={[styles.bubble, isUser ? styles.userBubble : styles.assistantBubble]}>
        <Text>Audio message</Text>
      </View>
    );
  }

  if (item.type === 'video') {
    return (
      <View style={[styles.bubble, isUser ? styles.userBubble : styles.assistantBubble]}>
        <Text>Video: {item.content}</Text>
      </View>
    );
  }

  return (
    <View style={[styles.bubble, isUser ? styles.userBubble : styles.assistantBubble]}>
      <Text style={isUser ? styles.userText : styles.assistantText}>{item.content}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  bubble: { padding:12, marginVertical:6, borderRadius:12, maxWidth:'80%' },
  userBubble: { backgroundColor:'#2b2b2b', alignSelf:'flex-end' },
  assistantBubble: { backgroundColor:'#f1f1f1', alignSelf:'flex-start' },
  userText: { color:'#fff' },
  assistantText: { color:'#000' },
  caption: { marginTop:6, fontSize:12, color:'#666' }
});
