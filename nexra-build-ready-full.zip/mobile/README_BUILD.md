# Building NEXRA with EAS (Android & iOS)

## 1) Create an Expo account
- Install EAS CLI: `npm install -g eas-cli`
- Sign up at https://expo.dev and then run `eas login` locally.

## 2) Configure the project
- Open `mobile/firebaseConfig.js` and paste your Firebase config.
- In `mobile/screens/LoginScreen.js` replace `YOUR_EXPO_GOOGLE_CLIENT_ID` with your Google OAuth client ID (Web client ID for Expo).
- In `mobile/components/ChatUI.js` replace BACKEND_URL with your backend URL if deployed.
- Ensure `mobile/assets/nexra-small.png` is your logo.

## 3) Initialize EAS and build
- From the mobile folder: `eas build:configure`
- Then build for Android: `eas build -p android --profile production`
- And for iOS: `eas build -p ios --profile production` (requires Apple dev account)

## 4) Download and install
- After the build completes, download the APK (Android) or IPA (iOS) from the Expo build page.
- Install the APK on Android devices or distribute the IPA via TestFlight for iOS.
