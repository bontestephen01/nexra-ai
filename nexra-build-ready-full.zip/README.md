# NEXRA — Build-ready package

This archive contains the complete NEXRA project with Expo config for Android and iOS builds.

Files of interest:
- mobile/ (Expo app)
- backend/ (Node/Express server with OpenAI forwarding)

Important: The backend includes a placeholder OpenAI key for easy testing. **Replace** it with a real key before deploying to production.

See `mobile/README_BUILD.md` for build steps.
