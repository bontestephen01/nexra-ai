import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, Image } from 'react-native';
import { signInWithEmailAndPassword, GoogleAuthProvider, signInWithCredential } from 'firebase/auth';
import * as Google from 'expo-auth-session/providers/google';
import { auth, db } from '../firebaseConfig';
import { doc, setDoc } from 'firebase/firestore';

export default function LoginScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const [request, response, promptAsync] = Google.useIdTokenAuthRequest({
    clientId: 'YOUR_EXPO_GOOGLE_CLIENT_ID.apps.googleusercontent.com'
  });

  React.useEffect(() => {
    if (response?.type === 'success') {
      const { id_token } = response.params;
      const credential = GoogleAuthProvider.credential(id_token);
      signInWithCredential(auth, credential).then(async ({ user }) => {
        await setDoc(doc(db, 'users', user.uid), { name: user.displayName, email: user.email, photoURL: user.photoURL }, { merge: true });
        navigation.replace('Chat');
      }).catch(err => Alert.alert('Login error', err.message));
    }
  }, [response]);

  const handleEmailLogin = async () => {
    try {
      await signInWithEmailAndPassword(auth, email, password);
      navigation.replace('Chat');
    } catch (err) {
      Alert.alert('Login failed', err.message);
    }
  };

  return (
    <View style={styles.container}>
      <Image source={require('../assets/nexra-small.png')} style={{ width: 96, height: 96, marginBottom: 12 }} />
      <Text style={styles.title}>Welcome to NEXRA</Text>
      <TextInput placeholder="Email" style={styles.input} value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" />
      <TextInput placeholder="Password" style={styles.input} secureTextEntry value={password} onChangeText={setPassword} />
      <TouchableOpacity style={styles.button} onPress={handleEmailLogin}><Text style={styles.buttonText}>Login</Text></TouchableOpacity>
      <TouchableOpacity style={styles.googleButton} onPress={() => promptAsync()} disabled={!request}><Text style={styles.googleText}>Continue with Google</Text></TouchableOpacity>
      <TouchableOpacity onPress={() => navigation.navigate('Signup')}><Text style={styles.link}>Create account</Text></TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex:1, alignItems: 'center', justifyContent:'center', padding:24 },
  title: { fontSize: 22, fontWeight: '700', marginBottom: 12 },
  input: { width: '100%', padding: 12, borderWidth:1, borderColor:'#ddd', borderRadius:8, marginBottom:12 },
  button: { backgroundColor:'#4b7bec', padding:12, borderRadius:8, width:'100%', alignItems:'center' },
  buttonText: { color:'#fff', fontWeight:'600' },
  googleButton: { marginTop:12, padding:12, borderRadius:8, width:'100%', alignItems:'center', borderWidth:1, borderColor:'#ccc' },
  googleText: { color:'#222' },
  link: { marginTop:12, color:'#4b7bec' }
});
