import React, { useState, useEffect, useRef } from 'react';
import { View, TextInput, TouchableOpacity, Text, FlatList, ActivityIndicator, KeyboardAvoidingView, Platform, StyleSheet } from 'react-native';
import { auth, db, storage } from '../firebaseConfig';
import { collection, addDoc, query, orderBy, limit, onSnapshot, serverTimestamp } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import * as ImagePicker from 'expo-image-picker';
import axios from 'axios';
import MessageBubble from './MessageBubble';

const BACKEND_URL = 'https://your-backend-url.com'; // placeholder

export default function ChatUI() {
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState([]);
  const listRef = useRef();
  const uid = auth.currentUser.uid;

  useEffect(() => {
    const q = query(collection(db, 'users', uid, 'messages'), orderBy('createdAt', 'asc'));
    const unsub = onSnapshot(q, snapshot => {
      const msgs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setMessages(msgs);
      setTimeout(() => listRef.current?.scrollToEnd?.({ animated: true }), 200);
    });
    return unsub;
  }, []);

  const sendText = async () => {
    if (!text.trim()) return;
    const userMsg = { role: 'user', content: text.trim(), type: 'text', createdAt: serverTimestamp() };
    await addDoc(collection(db, 'users', uid, 'messages'), userMsg);
    setText('');
    callAssistant([...messages.filter(m=>m.role!=='system'), userMsg]);
  };

  const callAssistant = async (messagesForAI) => {
    setLoading(true);
    try {
      const apiMsgs = messagesForAI.map(m => ({ role: m.role, content: m.content }));
      const resp = await axios.post(`${BACKEND_URL}/chat`, { messages: apiMsgs });
      const assistant = resp.data.assistant;
      const assistantMsg = { role: 'assistant', content: assistant.content || '', type: 'text', createdAt: serverTimestamp() };
      await addDoc(collection(db, 'users', uid, 'messages'), assistantMsg);
    } catch (err) {
      console.error(err);
      await addDoc(collection(db, 'users', uid, 'messages'), { role: 'assistant', content: 'Sorry — something went wrong.', type: 'text', createdAt: serverTimestamp() });
    } finally {
      setLoading(false);
    }
  };

  const pickImage = async () => {
    const res = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.8 });
    if (!res.cancelled) {
      const uri = res.uri;
      const blob = await (await fetch(uri)).blob();
      const filename = `images/${uid}/${Date.now()}`;
      const storageRef = ref(storage, filename);
      await uploadBytes(storageRef, blob);
      const url = await getDownloadURL(storageRef);
      const msg = { role: 'user', content: url, type: 'image', createdAt: serverTimestamp() };
      await addDoc(collection(db, 'users', uid, 'messages'), msg);

      const aiPrompt = f"Describe the image at this URL: {url}";
      const apiMsgs = [{ role: 'system', content: 'You are a smart and professional assistant.' }, { role: 'user', content: aiPrompt }];
      const resp = await axios.post(`${BACKEND_URL}/chat`, { messages: apiMsgs });
      const assistant = resp.data.assistant;
      const assistantMsg = { role: 'assistant', content: assistant.content || 'I cannot analyze the image right now.', type: 'text', createdAt: serverTimestamp() };
      await addDoc(collection(db, 'users', uid, 'messages'), assistantMsg);
    }
  };

  return (
    <View style={{ flex: 1 }}>
      <FlatList
        ref={listRef}
        data={messages}
        keyExtractor={item => item.id}
        renderItem={({ item }) => <MessageBubble item={item} />}
        contentContainerStyle={{ padding: 12, paddingBottom: 120 }}
      />

      {loading && <ActivityIndicator />}

      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
        <View style={styles.inputRow}>
          <TouchableOpacity onPress={pickImage} style={styles.mediaButton}><Text>+</Text></TouchableOpacity>
          <TextInput value={text} onChangeText={setText} placeholder="Type a message..." style={styles.input} onSubmitEditing={sendText} />
          <TouchableOpacity onPress={sendText} style={styles.sendButton}><Text style={{ color:'#fff' }}>Send</Text></TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  inputRow: { flexDirection: 'row', padding: 8, borderTopWidth: 0.5, borderColor: '#eee', alignItems: 'center' },
  mediaButton: { padding: 12, borderRadius: 24, marginRight: 8, backgroundColor: '#eee' },
  input: { flex: 1, padding: 12, borderRadius: 24, backgroundColor: '#f4f4f6' },
  sendButton: { marginLeft: 8, padding: 12, borderRadius: 24, backgroundColor: '#4b7bec' }
});
