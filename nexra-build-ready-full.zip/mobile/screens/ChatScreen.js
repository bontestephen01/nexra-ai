import React from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet } from 'react-native';
import { signOut } from 'firebase/auth';
import { auth, db } from '../firebaseConfig';
import ChatUI from '../components/ChatUI';

export default function ChatScreen({ navigation }) {
  const user = auth.currentUser;

  const handleLogout = async () => {
    await signOut(auth);
    navigation.replace('Login');
  };

  return (
    <View style={{ flex: 1 }}>
      <View style={styles.header}>
        {user?.photoURL ? <Image source={{ uri: user.photoURL }} style={styles.avatar} /> : <Image source={require('../assets/nexra-small.png')} style={styles.avatar} />}
        <View style={{ flex: 1 }}>
          <Text style={styles.title}>NEXRA</Text>
          <Text style={styles.subtitle}>Smart • Professional</Text>
        </View>
        <TouchableOpacity onPress={handleLogout}><Text style={{ color: 'red' }}>Logout</Text></TouchableOpacity>
      </View>

      <ChatUI />
    </View>
  );
}

const styles = StyleSheet.create({
  header: { padding: 12, flexDirection: 'row', alignItems: 'center', borderBottomWidth: 0.5, borderColor: '#eee' },
  avatar: { width: 44, height: 44, borderRadius: 10, marginRight: 12 },
  title: { fontSize: 18, fontWeight: '700' },
  subtitle: { color: '#666' }
});
